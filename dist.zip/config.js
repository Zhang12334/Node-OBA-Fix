import dotenv from 'dotenv';
import { z } from 'zod';
import env from 'env-var';
export class Config {
    static instance;
    clusterId = env.get('CLUSTER_ID').required().asString();
    clusterSecret = env.get('CLUSTER_SECRET').required().asString();
    clusterIp = env.get('CLUSTER_IP').asString();
    port = env.get('CLUSTER_PORT').default(4000).asPortNumber();
    clusterPublicPort = env.get('CLUSTER_PUBLIC_PORT').default(this.port).asPortNumber();
    byoc = env.get('CLUSTER_BYOC').asBool();
    disableAccessLog = env.get('DISABLE_ACCESS_LOG').asBool();
    enableNginx = env.get('ENABLE_NGINX').asBool();
    enableUpnp = env.get('ENABLE_UPNP').asBool();
    storage = env.get('CLUSTER_STORAGE').default('file').asString();
    storageOpts = env.get('CLUSTER_STORAGE_OPTIONS').asJsonObject();
    sslKey = env.get('SSL_KEY').asString();
    sslCert = env.get('SSL_CERT').asString();
    flavor;
    constructor() {
        this.flavor = {
            runtime: `Node.js/${process.version}`,
            storage: this.storage,
        };
    }
    static getInstance() {
        if (!Config.instance) {
            Config.instance = new Config();
        }
        return Config.instance;
    }
}
export const OpenbmclapiAgentConfigurationSchema = z.object({
    sync: z.object({
        source: z.string(),
        concurrency: z.number(),
    }),
});
dotenv.config();
export const config = Config.getInstance();
//# sourceMappingURL=config.js.map