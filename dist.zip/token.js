import got from 'got';
import ms from 'ms';
import { createHmac } from 'node:crypto';
import { logger } from './logger.js';
import { beforeError } from './modules/got-hooks.js';
export class TokenManager {
    clusterId;
    clusterSecret;
    token;
    got;
    prefixUrl = process.env.CLUSTER_BMCLAPI ?? 'https://openbmclapi.bangbang93.com';
    constructor(clusterId, clusterSecret, version) {
        this.clusterId = clusterId;
        this.clusterSecret = clusterSecret;
        this.got = got.extend({
            prefixUrl: this.prefixUrl,
            headers: {
                'user-agent': `openbmclapi-cluster/${version}`,
            },
            timeout: {
                request: ms('5m'),
            },
            hooks: {
                beforeError,
            },
        });
    }
    async getToken() {
        if (!this.token) {
            this.token = await this.fetchToken();
        }
        return this.token;
    }
    async fetchToken() {
        const challenge = await this.got
            .get('openbmclapi-agent/challenge', {
            searchParams: {
                clusterId: this.clusterId,
            },
        })
            .json();
        const signature = createHmac('sha256', this.clusterSecret).update(challenge.challenge).digest('hex');
        const token = await this.got
            .post('openbmclapi-agent/token', {
            json: {
                clusterId: this.clusterId,
                challenge: challenge.challenge,
                signature,
            },
        })
            .json();
        this.scheduleRefreshToken(token.ttl);
        return token.token;
    }
    scheduleRefreshToken(ttl) {
        const next = Math.max(ttl - ms('10m'), ttl / 2);
        setTimeout(() => {
            this.refreshToken().catch((err) => {
                logger.error(err, '刷新 Token 失败');
            });
        }, next);
        logger.trace(`计划在 ${next}ms 后刷新 Token`);
    }
    async refreshToken() {
        const token = await this.got
            .post('openbmclapi-agent/token', {
            json: {
                clusterId: this.clusterId,
                token: this.token,
            },
        })
            .json();
        logger.debug('刷新 Token 成功');
        this.scheduleRefreshToken(token.ttl);
        this.token = token.token;
    }
}
//# sourceMappingURL=token.js.map