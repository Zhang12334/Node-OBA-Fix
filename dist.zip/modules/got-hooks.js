import { ServiceError } from '@bangbang93/service-errors';
import { HTTPError } from 'got';
export const beforeError = [catchServiceError];
export function catchServiceError(error) {
    if (error instanceof HTTPError) {
        if (error.response.headers['content-type']?.includes('application/json')) {
            let body;
            if (Buffer.isBuffer(error.response.body)) {
                body = JSON.parse(error.response.body.toString('utf-8'));
            }
            else if (typeof error.response.body === 'object') {
                body = error.response.body;
            }
            else if (typeof error.response.body === 'string') {
                body = JSON.parse(error.response.body);
            }
            if (body && ServiceError.isServiceError(body)) {
                throw ServiceError.fromJSON(body);
            }
        }
    }
    return error;
}
//# sourceMappingURL=got-hooks.js.map